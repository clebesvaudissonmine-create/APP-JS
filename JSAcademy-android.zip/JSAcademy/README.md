# JS Academy

App Android (WebView) para aprender JavaScript. Todo o conteúdo fica em
`app/src/main/assets/index.html` e funciona offline.

## Gerar o APK (sem computador)
1. Suba todos os arquivos deste projeto para um repositório no GitHub.
2. Abra a aba **Actions** e rode **Build APK** (ou faça um commit na branch main).
3. Ao terminar, abra a execução e baixe o artefato **JSAcademy-APK**.
4. Descompacte e instale o `app-debug.apk` no celular.

## Atualizar o conteúdo
Edite `app/src/main/assets/index.html` e faça commit: o Actions gera um novo APK.
